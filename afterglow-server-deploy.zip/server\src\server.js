import http from "node:http";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { Server } from "socket.io";

const app = express();
app.set("trust proxy", 1);
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN?.split(",") || "*", methods: ["GET", "POST"] }));
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.get("/health", (_req, res) => res.json({ status: "ok" }));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.ALLOWED_ORIGIN?.split(",") || "*", methods: ["GET", "POST"] }, transports: ["websocket", "polling"] });
const rooms = new Map();
const safeCode = code => String(code || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12);
const validUrl = value => { try { const u = new URL(value); return ["http:", "https:"].includes(u.protocol); } catch { return false; } };

function snapshot(room, socketId) {
  return { roomCode: room.code, owner: room.ownerId === socketId, members: room.members.size, videoUrl: room.videoUrl, playing: room.playing, positionMs: room.positionMs };
}
function broadcast(room) { for (const id of room.members.keys()) io.to(id).emit("room-state", snapshot(room, id)); }

io.on("connection", socket => {
  socket.on("join-room", raw => {
    const code = safeCode(raw?.roomCode); const name = String(raw?.name || "Guest").trim().slice(0, 28);
    const mediaUrl = String(raw?.videoUrl || "").trim();
    if (code.length < 4) return socket.emit("room-error", "Use a room code with at least 4 characters.");
    if (mediaUrl && !validUrl(mediaUrl)) return socket.emit("room-error", "Please use a valid https:// media link.");
    let room = rooms.get(code);
    if (!room) { if (!mediaUrl) return socket.emit("room-error", "A host must add a film link when creating a room."); room = { code, ownerId: socket.id, videoUrl: mediaUrl, playing: false, positionMs: 0, members: new Map() }; rooms.set(code, room); }
    room.members.set(socket.id, name); socket.data.roomCode = code; socket.join(code); broadcast(room);
  });
  socket.on("sync-playback", raw => {
    const room = rooms.get(socket.data.roomCode); if (!room || room.ownerId !== socket.id) return;
    room.playing = Boolean(raw?.playing); room.positionMs = Math.max(0, Math.min(Number(raw?.positionMs) || 0, 86_400_000));
    socket.to(room.code).emit("playback", { ...snapshot(room, ""), owner: false });
  });
  socket.on("send-chat", raw => {
    const room = rooms.get(socket.data.roomCode); const body = String(raw?.body || "").trim().slice(0, 500); if (!room || !body) return;
    io.to(room.code).emit("chat", { sender: room.members.get(socket.id) || "Guest", body, timestamp: Date.now() });
  });
  socket.on("disconnect", () => {
    const room = rooms.get(socket.data.roomCode); if (!room) return;
    room.members.delete(socket.id);
    if (!room.members.size) return rooms.delete(room.code);
    if (room.ownerId === socket.id) room.ownerId = room.members.keys().next().value;
    broadcast(room);
  });
});
server.listen(process.env.PORT || 3000, "127.0.0.1", () => console.log("Afterglow server listening"));
