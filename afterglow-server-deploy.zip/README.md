# Afterglow — Android watch parties

An Android-native shared viewing app with host-controlled playback, room codes and live chat. The UI deliberately treats the room like a private cinema rather than a video-call dashboard.

## What it supports

- Direct playable media URLs (`.mp4`, HLS `.m3u8`, and formats supported by Android Media3)
- A six-to-twelve-character room code; the creator becomes host
- Playback synchronization over WebSockets, with late joiners seeking to the host's current position
- Host-only play/pause. If the host leaves, control transfers to the earliest remaining guest.
- Room chat and participant count

This does **not** redistribute copyrighted content or bypass streaming-provider DRM. Links must be media you are authorized to share. Services such as Netflix, Prime Video, and Disney+ cannot be played by embedding their normal web URLs.

## Configure Android

The Android app is preconfigured for `https://streamparty.duckdns.org`. Build using Android Studio (JDK 17) or `./gradlew assembleDebug` after generating the standard Gradle wrapper.

## Oracle VM deployment (Ubuntu)

1. Point `YOUR_DOMAIN` DNS A record to the VM. In Oracle Cloud's security list and Ubuntu firewall, allow TCP `80` and `443`; do not expose port `3000`.
2. On the VM install Node 20, Nginx and Certbot. Create a non-login user named `afterglow`, then copy `server/` to `/opt/afterglow/server` and set its ownership to that user.
3. From `/opt/afterglow/server`, run `npm ci --omit=dev` (or `npm install --omit=dev` until a lockfile is committed).
4. Replace every `YOUR_DOMAIN` in `deploy/nginx-afterglow.conf`, copy it to `/etc/nginx/sites-available/afterglow`, enable it, and test Nginx.
5. Obtain the certificate with `sudo certbot --nginx -d YOUR_DOMAIN`.
6. Copy `deploy/afterglow.service` to `/etc/systemd/system/afterglow.service`, then enable and start it: `sudo systemctl daemon-reload && sudo systemctl enable --now afterglow`.
7. Confirm `https://YOUR_DOMAIN/health` returns `{ "status": "ok" }`.

For real scale-out across multiple Node processes, swap the in-memory room map for Redis plus the Socket.IO Redis adapter. The included service is intentionally single-instance, which avoids inconsistent playback state.
